# from src.core.domain.repositories.user_repository_interface import UserRepositoryInterface


# class ValidateUserExists:
#     def __init__(self, user_repository : UserRepositoryInterface) -> None:
#         self.user_repository = user_repository

#     async def execute(self, ):
#         raise NotImplementedError
