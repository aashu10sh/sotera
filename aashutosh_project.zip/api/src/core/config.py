DATABASE_URL = "sqlite+aiosqlite:///./database.db"
COOKIE_KEY = "yedha yedha hi dharmasya"
